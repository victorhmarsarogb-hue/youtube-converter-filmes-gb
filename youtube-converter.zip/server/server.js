const express = require('express');
const ytdl = require('ytdl-core');
const ffmpeg = require('fluent-ffmpeg');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'client', 'dist')));

app.get('/api/download', async (req, res) => {
  const { url, format } = req.query;
  if (!url) return res.status(400).json({ error: 'Parâmetro url é obrigatório' });
  const targetFormat = (format === 'wav') ? 'wav' : 'mp3';

  try {
    if (!ytdl.validateURL(url)) return res.status(400).json({ error: 'URL inválida' });

    const info = await ytdl.getInfo(url);
    const titleSafe = info.videoDetails.title.replace(/[^a-z0-9\-]/gi, '_').slice(0, 120);
    const filename = `${titleSafe}.${targetFormat}`;

    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', 'audio/' + (targetFormat === 'mp3' ? 'mpeg' : 'wav'));

    const audioStream = ytdl(url, { quality: 'highestaudio' });
    const ffmpegProcess = ffmpeg(audioStream)
      .format(targetFormat)
      .on('error', (err) => {
        console.error('FFmpeg error:', err.message);
        if (!res.headersSent) res.status(500).json({ error: 'Erro durante conversão' });
      });

    ffmpegProcess.pipe(res, { end: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Erro interno' });
  }
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'client', 'dist', 'index.html'));
});

app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
