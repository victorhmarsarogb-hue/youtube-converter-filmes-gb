# Conversor YouTube → MP3/WAV

Projeto exemplo completo (server + client) para converter vídeos do YouTube em áudio.

⚠️ Use apenas para conteúdo que você tem direito de baixar.

## Rodar com Docker

```bash
docker build -t youtube-converter .
docker run -p 4000:4000 youtube-converter
```

Depois abra `http://localhost:4000`.
