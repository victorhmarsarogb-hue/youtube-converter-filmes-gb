import React, { useState } from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';

function App() {
  const [url, setUrl] = useState('');
  const [format, setFormat] = useState('mp3');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleDownload = async (e) => {
    e.preventDefault();
    setError(null);
    if (!url) return setError('Cole a URL do YouTube');
    setLoading(true);

    try {
      const params = new URLSearchParams({ url, format });
      const response = await fetch(`/api/download?${params.toString()}`);
      if (!response.ok) {
        const err = await response.json().catch(() => ({}));
        throw new Error(err.error || 'Erro no servidor');
      }

      const blob = await response.blob();
      const disposition = response.headers.get('Content-Disposition') || '';
      let filename = `audio.${format}`;
      const match = /filename=\"?([^\"]+)\"?/.exec(disposition);
      if (match) filename = match[1];

      const urlBlob = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = urlBlob;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(urlBlob);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app-container">
      <header>
        <h1>Conversor YouTube → MP3 / WAV</h1>
      </header>
      <main>
        <form onSubmit={handleDownload} className="form">
          <label>Link do YouTube</label>
          <input value={url} onChange={e => setUrl(e.target.value)} placeholder="Cole a URL aqui" />
          <label>Formato</label>
          <select value={format} onChange={e => setFormat(e.target.value)}>
            <option value="mp3">MP3 (compress)</option>
            <option value="wav">WAV (lossless)</option>
          </select>
          <button type="submit" disabled={loading}>{loading ? 'Convertendo...' : 'Converter e Baixar'}</button>
          {error && <p className="error">{error}</p>}
          <p className="small">Use somente para conteúdo que você tem direito de baixar.</p>
        </form>
      </main>
      <footer>
        <small>Projeto de exemplo — não para distribuição massiva.</small>
      </footer>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
